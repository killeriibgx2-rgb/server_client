package pack;
import java.nio.file.*;import java.util.*;import java.util.stream.*;
import net.minecraftforge.fml.loading.*;import net.minecraftforge.fml.loading.moddiscovery.AbstractJarFileModLocator;
public final class Locator extends AbstractJarFileModLocator {
 public String name(){return "ServerPack";} public void initArguments(Map<String,?> args){}
 public Stream<Path> scanCandidates(){try{Path game=FMLPaths.GAMEDIR.get();boolean server=FMLLoader.getDist().isDedicatedServer();if(server)Host.start(game);Path ui=game.resolve("config/serverpack/runtime/serverpack-ui.jar");Files.createDirectories(ui.getParent());try(var in=Locator.class.getResourceAsStream("/payload/ui.bin")){if(in==null)throw new java.io.IOException("Missing interface payload");byte[] bytes=in.readAllBytes();if(!Files.exists(ui)||!Arrays.equals(bytes,Files.readAllBytes(ui))){Path tmp=Files.createTempFile(ui.getParent(),"ui-",".tmp");Files.write(tmp,bytes);Files.move(tmp,ui,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}}if(server)return Stream.of(ui);return Stream.concat(Stream.of(ui),Client.run(game).stream());}catch(Exception e){throw new IllegalStateException("ServerPack: "+e.getMessage(),e);}}
}
