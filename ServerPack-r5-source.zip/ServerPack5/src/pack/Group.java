package pack;
import java.io.*;import javax.crypto.*;import javax.crypto.spec.*;import java.util.HexFormat;import java.nio.charset.StandardCharsets;
public final class Group{public static String mac(String value)throws Exception{Mac m=Mac.getInstance("HmacSHA256");try(var in=Group.class.getResourceAsStream("/pair/group.bin")){m.init(new SecretKeySpec(in.readAllBytes(),"HmacSHA256"));}return HexFormat.of().formatHex(m.doFinal(value.getBytes(StandardCharsets.UTF_8)));}}
