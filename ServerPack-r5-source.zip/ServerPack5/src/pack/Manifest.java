package pack;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;

/** Deterministic UTF-8 TSV: digest, byte length, base name. No absolute paths on wire. */
public final class Manifest {
    public static String scan(Path mods, List<String> selected) throws IOException {
        Set<String> unique = new TreeSet<>();
        for (String line : selected) {
            String n = line.strip();
            if (n.isEmpty() || n.startsWith("#")) continue;
            if (!n.matches("[A-Za-z0-9_+() .\\-]{1,180}\\.jar") || n.startsWith(".") || !unique.add(n))
                throw new IOException("Invalid or duplicate mod name: " + n);
        }
        StringBuilder out = new StringBuilder("serverpack-v1\n");
        for (String n : unique) {
            Path p = mods.resolve(n);
            if (!Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Missing regular mod: " + n);
            MessageDigest h;
            try { h = MessageDigest.getInstance("SHA-256"); } catch (NoSuchAlgorithmException e) { throw new AssertionError(e); }
            long bytes;
            try (InputStream in = new DigestInputStream(Files.newInputStream(p, LinkOption.NOFOLLOW_LINKS), h)) { bytes = in.transferTo(OutputStream.nullOutputStream()); }
            StringBuilder digest = new StringBuilder(); for (byte b : h.digest()) digest.append(String.format("%02x", b & 255));
            out.append(digest).append('\t').append(bytes).append('\t').append(n).append('\n');
        }
        return out.toString();
    }
}
