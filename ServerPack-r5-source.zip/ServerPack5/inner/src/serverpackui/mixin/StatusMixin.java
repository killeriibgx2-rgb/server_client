package serverpackui.mixin;
import net.minecraft.network.protocol.status.ClientboundStatusResponsePacket;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;
@Mixin(value=ClientboundStatusResponsePacket.class,remap=false) public class StatusMixin{
 @ModifyArg(method="m_5779_",at=@At(value="INVOKE",target="Lnet/minecraft/network/FriendlyByteBuf;m_130070_(Ljava/lang/String;)Lnet/minecraft/network/FriendlyByteBuf;"),index=0,remap=false)
 private String friends$advertise(String json){String ad=System.getProperty("friends.serverpack.ad.v5");if(ad==null||!json.endsWith("}")||json.length()+ad.length()+20>32767)return json;return json.substring(0,json.length()-1)+",\"serverpack5\":\""+ad+"\"}";}
}
