package serverpackui.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;import net.minecraft.client.gui.screens.*;import net.minecraft.client.*;import net.minecraft.client.multiplayer.*;import net.minecraft.client.multiplayer.resolver.*;import serverpackui.Join;
@Mixin(value=ConnectScreen.class,remap=false) public class JoinMixin{
 @Inject(method="m_278792_",at=@At("HEAD"),cancellable=true,remap=false) private static void serverpack$before(Screen parent,Minecraft mc,ServerAddress address,ServerData data,boolean quick,CallbackInfo ci){if(Join.begin(parent,mc,address,data,quick))ci.cancel();}
}
