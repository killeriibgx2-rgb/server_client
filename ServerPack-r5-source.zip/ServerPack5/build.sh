#!/usr/bin/env bash
# Java 17; paths to the client and server directories populated by Forge installer.
set -euo pipefail
client=$(realpath "${1:?Specify Forge client directory}")
server=$(realpath "${2:?Specify Forge server directory}")
cd "$(dirname "$0")"
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
srg=$(find "$client/libraries/net/minecraft/client" -name '*-srg.jar' -print -quit); test -f "$srg"
cp="$srg:$(find "$server/libraries" "$client/libraries" -name '*.jar' | paste -sd: -)"
mkdir -p "$tmp"/{ui,outer,assets}; cp -R services/. "$tmp/assets/"
javac -encoding UTF-8 -proc:none -cp "$cp" -d "$tmp/ui" $(find inner/src -name '*.java')
javac -encoding UTF-8 -proc:none -cp "$cp" -d "$tmp/outer" src/pack/*.java
printf 'MixinConfigs: serverpack.mixins.json\n' > "$tmp/ui.mf"
jar cfm "$tmp/assets/payload/ui.bin" "$tmp/ui.mf" -C "$tmp/ui" . -C inner/resources .
printf 'Automatic-Module-Name: friends.serverpack.locator\n' > "$tmp/mod.mf"
jar cfm ServerPack-r5.jar "$tmp/mod.mf" -C "$tmp/outer" . -C "$tmp/assets" .
